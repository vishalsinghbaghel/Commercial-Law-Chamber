export const Expertise = () => {
    
    return (
        <>
            expertise page
        </>
    )
}