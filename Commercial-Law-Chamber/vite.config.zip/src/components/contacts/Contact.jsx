export const Contact = () => {
    return (
        <>
        Contact page
       </>
    )
};
