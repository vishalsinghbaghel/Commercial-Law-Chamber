export const Insights = () => {
    return (
        <>
            about page
        </>
    )
};
